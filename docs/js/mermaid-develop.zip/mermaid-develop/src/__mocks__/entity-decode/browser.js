module.exports = function(txt) {
  return txt;
};
