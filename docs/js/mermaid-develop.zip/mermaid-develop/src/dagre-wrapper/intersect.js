module.exports = {
  node: require('./intersect-node'),
  circle: require('./intersect-circle'),
  ellipse: require('./intersect-ellipse'),
  polygon: require('./intersect-polygon'),
  rect: require('./intersect-rect')
};
