import matplotlib.pyplot as plt
import numpy as np
import util # 加载标准输入输出的函数
util.init(__file__)# 初始化
d = util.loadoutput()# 加载数据输出
testy = d['testy']
a,b = d['a'],d['b']

def f(x):
    y =a*x +b
    return y
d = util.loadinput()# 加载数据输入
testx = d['testx']
dataxy = d['xy']

x = np.linspace(0,10)
y = f(x)
plt.figure()
plt.plot(testx,testy,'bo',label='test')
plt.plot(x,y,'b-',label='lse')
plt.plot(dataxy[0],dataxy[1],'ro',label='raw')
plt.legend()
util.savefig('plot') # 保存图片,plot.png，到同目录。
plt.show()

