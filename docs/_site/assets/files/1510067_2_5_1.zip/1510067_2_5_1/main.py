'''
2.5.1
线性回归，最小二乘
'''
import torch

def lse(dataxy):
    '''
    return a,b,f
    f(x) = ax+b

    d = [[x],
        [y]]
    '''
    tsr = torch.tensor(dataxy).float()
    x=  tsr[0,:]
    y=  tsr[1,:]

    #x,xmean,xsvar = normalize(x)
    #y,ymean,ysvar = normalize(y)

    o = torch.ones_like(x)
    xx = torch.stack((x,o),-1)
    A = xx.t()@xx
    B =  torch.stack((xx.t()@y,),-1)
    arg=  torch.solve(B,A).solution
    a,b = arg[0].item(),arg[1].item()
    def f(x):
        return a*x+b
    return a,b,f


from util import * # 导入标准输入输出函数
init(__file__) # 初始化
d = loadinput() # 加载数据输入，一个字典

dataxy = d['xy']

a,b,f=  lse(dataxy) # 计算

testx = d['testx']
testy=  [f(x) for x in testx]
save({'testy':testy,'a':a,'b':b}) #保存数据输出
        