from util import *
init(__file__)

dataxy = [[4.2,7.1,6.3,1.1,0.2,4.0,3.5,8,2.3],
    [8600,6100,6700,12000,14200,8500,8900,6200,11200]]

testx = [1.3,5.3,7.3]

fcode='''def f(x,a,b):
    return ax+b'''

d = {'xy':dataxy,'f':fcode,'testx':testx} # 数据输入的实际格式，一个字典

makeinput(d)# 保存数据输入
