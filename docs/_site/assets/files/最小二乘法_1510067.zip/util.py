'''
标准输入输出。
'''
# Student

import shelve
import warnings
import os
import matplotlib.pyplot as plt


common = {}
shelve_open= []


def init(p:'__file__'):
    '''
    初始化。生成随处路径和文件名。

    使用如下语句调用：

    ````python
    init(__file__)
    ````

    '''
    cfp,cfn =os.path.split(os.path.abspath(p)) 
    cfn = cfn.split('.')[0]
    common['cfp'] = cfp
    common['cfn'] = cfn
    common['input_file'] = os.path.join(cfp,'data')
    common['output_file'] = os.path.join(cfp,'result')

def _load(key):
    if key not in common:
        raise Exception('Call init(__file__) first.')
    file = common[key]
    sh = shelve.open(file,flag='r')
    r=  dict(sh)
    sh = shelve_mgr(sh)
    shelve_open.append(sh)
    return r

def loadinput()->dict:
    '''
    加载数据输入，返回一个字典。
    '''
    r = _load('input_file')
    return r

def loadoutput()->dict:
    '''
    加载数据输出，返回一个字典。
    '''
    r = _load('output_file')
    return r

def save(d:dict):
    '''
    保存数据输出。
    '''
    if 'output_file' not in common:
        raise Exception('Call init(call) first.')
    output_file = common['output_file']
    output_sh = shelve.open(output_file,flag='c')
    output_sh.update(d)
    output_sh.close()

def savefig(name):
    '''
    在同目录保存matplotlib.pyplot绘制的图片。
    '''
    plt.savefig(os.path.join(common['cfp'],'{}.png'.format(name)))

class shelve_mgr:
    def __init__(self,sh):
        self.sh  = sh
    def __del__(self):
        self.sh.close()


# Teacher

def makeinput(d:dict):
    '''
    保存数据输入。
    '''
    if 'input_file' not in common:
        raise Exception('Call init(__file__) first.')
    input_file =common['input_file']
    sh = shelve.open(input_file,flag='n')
    sh.update(d)
    sh.close()