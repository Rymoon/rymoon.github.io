from util import *
init(__file__)
r = loadoutput()
print(r)
